//	*******************************************************
//	Toggle element to hide/show
//	*******************************************************

// Step 1: Get a handle on the clickable element and create a variable to hold it

// Step 2: Get a handle on the element to be toggled and create a variable to hold it

// Step 3: Set the default state of the element to be toggled; either "inline" (showing) or "none" (hidden)

// Step 4: write the function to do the toggling (won't execute 'til called) - have it take-in an 'element'

	// Step 4a: IF display:inline, it must be showing, so hide it

	// Step 4b: ELSE it must be hidden, so show it

// Step 5: Apply a "click listener" to the clickable element, and when the element is clicked, run the function